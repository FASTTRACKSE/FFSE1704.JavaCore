package fasttrackse.javacore.entity;

public abstract class Hinh {
	public abstract double tinhDienTich();
	public abstract double tinhChuVi();
}
