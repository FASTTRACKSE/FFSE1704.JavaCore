package project.quanlithuvien.main;

import project.quanlithuvien.ui.QuanLiThuVienUI;

public class QuanLiThuVien {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuanLiThuVienUI myThuVien = new QuanLiThuVienUI("Quản Lí Thư Viện ");
		myThuVien.showWindow();
	}

}
	