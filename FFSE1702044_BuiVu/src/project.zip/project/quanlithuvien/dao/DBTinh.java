package project.quanlithuvien.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.mysql.jdbc.Driver;

import project.quanlithuvien.untity.QuanLiDiaChi;
import project.quanlithuvien.untity.QuanLiSach;

public class DBTinh {
	static Connection conn = null;

	/**
	 * @return the conn
	 */
	public static Connection getConn() {
		return conn;
	}

	/**
	 * @param conn
	 *            the conn to set
	 */
	public void setConn(Connection conn) {
		this.conn = conn;
	}
	
	public ArrayList<QuanLiDiaChi> List() {
		ArrayList<QuanLiDiaChi> dsTinh = new ArrayList<QuanLiDiaChi>();
		try {
			String queryString = "SELECT provinceid,name FROM `province`";
			PreparedStatement statement = conn.prepareStatement(queryString);

			ResultSet result = statement.executeQuery();

			while (result.next()) {

				String id= result.getString("provinceid");
				String Tinh = result.getString("name");
				dsTinh.add(new QuanLiDiaChi(id,Tinh));
			
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return dsTinh;
	}

	public static Connection getConnect(String strServer, String strDatabase, String strUser, String strPwd) {

		String strConnect = "jdbc:mysql://" + strServer + "/" + strDatabase + "?useUnicode=yes&characterEncoding=UTF-8";
		Properties pro = new Properties();
		pro.put("user", strUser);
		pro.put("password", strPwd);
		try {
			com.mysql.jdbc.Driver driver = new Driver();
			conn = driver.connect(strConnect, pro);
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return conn;
	}
}
