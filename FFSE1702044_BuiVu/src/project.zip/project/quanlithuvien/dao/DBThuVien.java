package project.quanlithuvien.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Driver;

import project.quanlithuvien.untity.QuanLiSach;
import project.quanlithuvien.untity.QuanLiThongTin;

public class DBThuVien {
	static Connection conn = null;

	/**
	 * @return the conn
	 */
	public static Connection getConn() {
		return conn;
	}

	/**
	 * @param conn
	 *            the conn to set
	 */
	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public static Connection getConnect(String strServer, String strDatabase, String strUser, String strPwd) {

		String strConnect = "jdbc:mysql://" + strServer + "/" + strDatabase + "?useUnicode=yes&characterEncoding=UTF-8";
		Properties pro = new Properties();
		pro.put("user", strUser);
		pro.put("password", strPwd);
		try {
			com.mysql.jdbc.Driver driver = new Driver();
			conn = driver.connect(strConnect, pro);
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return conn;
	}

	public ArrayList<QuanLiSach> getDSSach() {
		ArrayList<QuanLiSach> dsSach = new ArrayList<QuanLiSach>();
		try {
			String queryString = "SELECT Ma_sach,Ten_sach,Tac_gia,NXB,The_loai_sach.The_loai,nam_XB FROM quan_li_sach INNER JOIN The_loai_sach ON The_loai_sach.id= quan_li_sach.The_loai_sach ";
			PreparedStatement statement = conn.prepareStatement(queryString);

			ResultSet result = statement.executeQuery();

			while (result.next()) {

				String maSach = result.getString("Ma_sach");
				String tenSach = result.getString("Ten_sach");
				String TacGia = result.getString("Tac_gia");
				String nXB = result.getString("NXB");
				String TheLoaiSach = result.getString("The_loai_sach.The_loai");
				String NamXB = result.getString("nam_XB");

				dsSach.add(new QuanLiSach(maSach, tenSach, TacGia, nXB, TheLoaiSach, NamXB));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return dsSach;
	}

	/*
	 * public ArrayList<QuanLiThongTin> login(QuanLiThongTin tt) {
	 * ArrayList<QuanLiThongTin> dsTT = new ArrayList<QuanLiThongTin>(); try {
	 * String queryString =
	 * "SELECT * FROM TTDangNhap where pass='?' and user_name='?' ";
	 * PreparedStatement statement = conn.prepareStatement(queryString);
	 * 
	 * ResultSet result = statement.executeQuery();
	 * 
	 * while (result.next()) { JOptionPane.showMessageDialog(null,
	 * "Đăng Nhập Thành Công "); }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } return dsTT; } public void
	 * add(KhachHang kh) { // try { String queryString =
	 * "insert into khachhang(MaKH,TenKH,DiaChi,NgaySinh,GioiTinh,SoDT) values(?,?,?,?,?,?)"
	 * ; PreparedStatement statement = conn.prepareStatement(queryString);
	 * 
	 * statement.setString(1, kh.getMaKH()); statement.setString(2, kh.getTenKH());
	 * statement.setString(3, kh.getDiaChi()); statement.setString(4,
	 * kh.getNgaySinh()); statement.setString(5, kh.getGioiTinh());
	 * statement.setString(6, kh.getSoDT());
	 * 
	 * int x = statement.executeUpdate(); if (x > 0) {
	 * System.err.println("Thêm OK!"); } } catch (Exception ex) {
	 * ex.printStackTrace(); } }
	 * 
	 * public void edit(KhachHang kh) { // try { String sql =
	 * "update khachhang set TenKH=?,NgaySinh=? where id=?"; PreparedStatement
	 * statement = conn.prepareStatement(sql); statement.setString(1,
	 * kh.getTenKH()); statement.setString(2, kh.getNgaySinh());
	 * statement.setLong(3, kh.getID()); int x = statement.executeUpdate(); if (x >
	 * 0) { System.err.println("Cập nhật OK"); } } catch (Exception ex) {
	 * ex.printStackTrace(); } }
	 * 
	 * public void delete(int idKH) { // try { PreparedStatement statement =
	 * conn.prepareStatement("DELETE FROM `khachhang` WHERE id=?");
	 * statement.setLong(1, idKH); int x = statement.executeUpdate(); if (x > 0) {
	 * System.out.println("Xóa ok"); } } catch (Exception ex) {
	 * ex.printStackTrace(); } }
	 */
	public  void timKiem(QuanLiSach sach) {
	

		try {
			String queryString = "SELECT * FROM `quan_li_sach` WHERE Ten_sach = '?' ";
			PreparedStatement statement = conn.prepareStatement(queryString);
			statement.setString(1, sach.getTimKiem());
			ResultSet result = statement.executeQuery();
			result.next();

			String maSach = result.getString("Ma_sach");
			String tenSach = result.getString("Ten_sach");
			String TacGia = result.getString("Tac_gia");
			String nXB = result.getString("NXB");
			String TheLoaiSach = result.getString("The_loai");
			String NamXB = result.getString("nam_XB");

			

			sach = new QuanLiSach(maSach, tenSach, TacGia, nXB, TheLoaiSach, NamXB);
		} catch (Exception e) {
			e.printStackTrace();
		}

	
	}

}
