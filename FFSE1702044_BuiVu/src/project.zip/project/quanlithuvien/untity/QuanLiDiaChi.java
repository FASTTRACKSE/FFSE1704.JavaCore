package project.quanlithuvien.untity;

public class QuanLiDiaChi {
	private String id,Tinh;

	public QuanLiDiaChi(String id, String tinh) {
		
		this.id = id;
		Tinh = tinh;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTinh() {
		return Tinh;
	}

	public void setTinh(String tinh) {
		Tinh = tinh;
	}

	
}
